### References

* http://www.contrib.andrew.cmu.edu/~somlo/OSXKVM/

* https://www.kraxel.org/blog/2017/09/running-macos-as-guest-in-kvm/

* https://github.com/foxlet/macOS-Simple-KVM

* https://support.apple.com/en-us/HT211683 (How to get old versions of macOS)

* https://github.com/sickcodes/Docker-OSX/issues/341#issuecomment-919913745 (awesome qemu automation)

* https://github.com/ofawx/VmAssetCacheEnable

* https://dortania.github.io/OpenCore-Install-Guide/troubleshooting/extended/post-issues.html

- https://wiki.archlinux.org/title/QEMU#UNIX_socket

- https://wiki.archlinux.org/title/PCI_passthrough_via_OVMF#USB_controller
